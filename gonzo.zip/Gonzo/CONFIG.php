<?php

	/* CONFIG FILE
	 * 14-12-12
	 * Anything global contained here.
	 * All major settings here.
	 * # Not standard practice, but it'll make it easier in the long
	 * # run.
	 */
	 
	$title = "Gonzo";
	
	$db_host = 'localhost';
	$db_user = 'root';
	$db_pass = 'toor';
	$db_name = 'gonzo3';
	
	// =============================
	// =============================
	 
	$max_username = 16;			// MAX char allowed for username
	$max_password = 32;			// MAX char allowed for passwords
	
	

?>
