GONZO Script v1.0
======================
Last Update 2012-12-21

INSTALLATION

Just extract gonzo.zip to your WWW directory.

CONFIGURATION

Edit "CONFIG.php". Your MySQL details are required, so the script can
setup its database and tables it is going to work from.

"gonzo.css" holds all the formatting and styling information.

HEADER IMGS

Any JPEG, GIF and PNG images can be dropped into the "header_imgs"
directory.



Any Queries:

Clint
clint.veasey@gmail.com
