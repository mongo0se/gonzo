<?php

	/* connect.php
	 * 14-12-12
	 * Define connection settings.
	 * Re-occuring code for connecting to DB in here.
	*/ 
	
	include 'CONFIG.php';
	
	function connectToDB($host, $user, 
	                     $pass, $name)
	{
		$con = mysql_connect($host, $user, $pass);
	    mysql_select_db($name);
	    
	    return $con;
		
	}

?>
